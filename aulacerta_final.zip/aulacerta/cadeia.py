"""Cadeia do AulaCerta: prompt 1 -> busca na base -> prompt 2 -> prompt 3 -> prompt 4.

O código confere o que é exato (códigos BNCC, soma dos tempos) e grava um log de cada execução.
"""
import json
import os
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

import prompts
from bncc import buscar, carregar_base

load_dotenv()
MODELO = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
PASTA_LOGS = Path(__file__).parent / "logs"


class ErroAulaCerta(Exception):
    """Erro que deve ser mostrado ao professor."""


def chamar_modelo(cliente, prompt: str, tentativas: int = 2) -> dict:
    """Chama o modelo pedindo JSON. Se a resposta não for um JSON válido, tenta de novo uma vez."""
    for tentativa in range(tentativas):
        resposta = cliente.chat.completions.create(
            model=MODELO,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
        )
        texto = resposta.choices[0].message.content
        try:
            return json.loads(texto)
        except json.JSONDecodeError:
            if tentativa == tentativas - 1:
                raise ErroAulaCerta("O modelo devolveu uma resposta em formato inválido. Tente de novo.")


def formatar_habilidades(habilidades: list[dict]) -> str:
    return "\n".join(f"- {h['codigo']} ({h['ano']}º ano): {h['texto']}" for h in habilidades)


def conferir_correcoes(plano_original: dict, plano_revisado: dict, verificacoes: list) -> list:
    """Registra mudanças reais entre os planos, sem confiar apenas no rótulo da IA."""
    resultado = []
    for item in verificacoes:
        item = dict(item)
        if item.get("resultado") == "CORRIGIDO":
            pergunta = str(item.get("pergunta", "")).lower()
            if "resposta" in pergunta or "exercício" in pergunta:
                campo = "exercicios"
            elif "objetivo" in pergunta or "etapa" in pergunta and "habilidade" in pergunta:
                campo = None  # envolve mais de uma parte do plano
            else:
                campo = None
            antes = plano_original.get(campo) if campo else plano_original
            depois = plano_revisado.get(campo) if campo else plano_revisado
            if antes == depois:
                item["resultado"] = "ATENÇÃO"
                item["detalhe"] = ("A IA informou CORRIGIDO, mas não houve alteração "
                                   "detectável no conteúdo correspondente. " + str(item.get("detalhe", "")))
            elif campo == "exercicios":
                item["detalhe"] = ("Mudanças detectadas na lista de exercícios; "
                                   "a correção matemática ainda requer conferência. " + str(item.get("detalhe", "")))
        resultado.append(item)
    return resultado


def somar_minutos(plano: dict) -> int:
    """Soma os tempos e rejeita durações ausentes, negativas ou inválidas."""
    etapas = plano.get("etapas")
    if not isinstance(etapas, list) or not etapas:
        raise ErroAulaCerta("O plano não contém etapas válidas.")
    total = 0
    for etapa in etapas:
        if not isinstance(etapa, dict) or type(etapa.get("minutos")) is not int or etapa["minutos"] <= 0:
            raise ErroAulaCerta("Há uma etapa sem duração inteira e positiva.")
        total += etapa["minutos"]
    return total


def corrigir_duracao(cliente, plano: dict, duracao: int, log: dict, avisar) -> dict:
    """Solicita uma correção adicional e só aceita o resultado se o Python confirmar."""
    soma_inicial = somar_minutos(plano)
    if soma_inicial == duracao:
        return plano

    avisar(f"Corrigindo duração: {soma_inicial} min em vez de {duracao} min")
    prompt = (
        "Você é um revisor de planos de aula. Responda APENAS com um objeto JSON válido "
        "que contenha o plano completo (sem campos externos).\n"
        f"A duração obrigatória é {duracao} minutos, mas a soma atual é {soma_inicial}. "
        "Ajuste os minutos das etapas para que a soma seja EXATAMENTE a duração pedida. "
        "Mantenha todas as etapas, objetivos, habilidades, exercícios, respostas e demais campos "
        "inalterados. Cada etapa deve ter um número inteiro positivo de minutos. "
        "Confira a soma antes de responder.\nPlano atual:\n"
        + json.dumps(plano, ensure_ascii=False, indent=2)
    )
    log["etapas"]["5_correcao_duracao"] = {"soma_inicial": soma_inicial, "tentativas": []}
    for tentativa in range(2):
        revisado = chamar_modelo(cliente, prompt)
        registro = {"tentativa": tentativa + 1}
        try:
            soma = somar_minutos(revisado)
            registro["soma"] = soma
        except ErroAulaCerta as erro:
            registro["erro"] = str(erro)
            soma = None
        # A correção automática só pode alterar os minutos das etapas.
        def sem_minutos(valor):
            copia = json.loads(json.dumps(valor, ensure_ascii=False))
            if isinstance(copia.get("etapas"), list):
                for etapa in copia["etapas"]:
                    if isinstance(etapa, dict):
                        etapa.pop("minutos", None)
            return copia
        preservado = isinstance(revisado, dict) and sem_minutos(revisado) == sem_minutos(plano)
        registro["outros_campos_preservados"] = preservado
        log["etapas"]["5_correcao_duracao"]["tentativas"].append(registro)
        if soma == duracao and preservado:
            log["etapas"]["5_correcao_duracao"]["plano_corrigido"] = revisado
            return revisado
        prompt += (f"\nSua última tentativa não foi aceita. A soma foi {soma} e "
                   f"os demais campos foram preservados: {preservado}. Tente novamente.")
    raise ErroAulaCerta(
        f"Não foi possível ajustar automaticamente a duração para {duracao} minutos. "
        "O plano não será apresentado como validado."
    )


def gerar_plano(serie: int, tema: str, duracao: int, perfil: str = "", ao_avancar=None, cliente=None) -> dict:
    """Executa a cadeia completa e devolve o plano, as verificações e o registro de cada etapa."""
    avisar = ao_avancar or (lambda texto: None)
    cliente = cliente or OpenAI()
    base = carregar_base()
    perfil = perfil.strip() or "turma regular"
    log = {"data": datetime.now().isoformat(timespec="seconds"), "modelo": MODELO,
           "pedido": {"serie": serie, "tema": tema, "duracao": duracao, "perfil": perfil}, "etapas": {}}
    verificacoes_codigo = []

    # Prompt 1 – Análise do pedido
    avisar("Prompt 1: analisando o tema e quebrando em subtópicos")
    analise = chamar_modelo(cliente, prompts.PROMPT_1_ANALISE.format(
        serie=serie, tema=tema, duracao=duracao, perfil=perfil))
    log["etapas"]["1_analise"] = analise

    # Busca na base (código, sem IA)
    avisar("Buscando habilidades candidatas na base BNCC")
    palavras = analise.get("palavras_chave", []) + [tema]
    candidatas = buscar(base, serie, palavras)
    log["etapas"]["busca"] = [h["codigo"] for h in candidatas]
    if not candidatas:
        raise ErroAulaCerta("Não encontrei habilidades da BNCC para esse tema. Tente descrever o tema de outro jeito.")

    # Prompt 2 – Seleção de habilidades
    avisar("Prompt 2: escolhendo as habilidades que combinam com o tema")
    selecao = chamar_modelo(cliente, prompts.PROMPT_2_SELECAO.format(
        tema=tema, serie=serie, subtopicos="; ".join(analise.get("subtopicos", [])),
        candidatas=formatar_habilidades(candidatas)))
    log["etapas"]["2_selecao"] = selecao

    codigos_candidatos = {h["codigo"] for h in candidatas}
    selecionadas = []
    for item in selecao.get("selecionadas", []):
        codigo = str(item.get("codigo", "")).strip().upper()
        if codigo in codigos_candidatos:
            hab = base[codigo]
            tipo = "principal" if hab["ano"] == serie else "retomada"  # a série decide, não o modelo
            selecionadas.append({**hab, "tipo": tipo, "justificativa": item.get("justificativa", "")})
        else:
            verificacoes_codigo.append({"pergunta": f"O código {codigo} escolhido no prompt 2 está entre as candidatas?",
                                        "resultado": "CORRIGIDO", "detalhe": "Código fora da base foi descartado."})
    if not selecionadas:
        raise ErroAulaCerta("Nenhuma habilidade da BNCC combinou com esse tema. Tente descrever o tema de outro jeito.")

    texto_habilidades = "\n".join(
        f"- {h['codigo']} ({h['ano']}º ano, {h['tipo']}): {h['texto']}" for h in selecionadas)

    # Prompt 3 – Redação do plano
    avisar("Prompt 3: escrevendo o plano de aula")
    plano = chamar_modelo(cliente, prompts.PROMPT_3_PLANO.format(
        serie=serie, duracao=duracao, tema=tema, perfil=perfil,
        subtopicos="; ".join(analise.get("subtopicos", [])), habilidades=texto_habilidades))
    log["etapas"]["3_plano"] = plano

    # Prompt 4 – Verificação
    avisar("Prompt 4: verificando o plano")
    verificacao = chamar_modelo(cliente, prompts.PROMPT_4_VERIFICACAO.format(
        plano=json.dumps(plano, ensure_ascii=False, indent=2), habilidades=texto_habilidades, duracao=duracao))
    plano_final = verificacao.get("plano") or plano
    verificacao["verificacoes"] = conferir_correcoes(
        plano, plano_final, verificacao.get("verificacoes", []))
    log["etapas"]["4_verificacao"] = verificacao

    # Se o quarto prompt não respeitou a duração, fazer uma correção adicional.
    # O resultado só é aceito após conferência independente pelo Python.
    plano_final = corrigir_duracao(cliente, plano_final, duracao, log, avisar)

    # Verificações feitas pelo código (o que é exato não fica por conta do modelo)
    avisar("Conferindo códigos BNCC e soma dos tempos")
    por_codigo = {h["codigo"]: h for h in selecionadas}
    citados = [str(h.get("codigo", "")).strip().upper() for h in plano_final.get("habilidades", [])]
    invalidos = [c for c in citados if c not in por_codigo]
    habilidades_finais = [por_codigo[c] for c in dict.fromkeys(citados) if c in por_codigo] or selecionadas
    verificacoes_codigo.append({
        "pergunta": "Todos os códigos do plano final vêm da base BNCC e foram selecionados?",
        "resultado": "CORRIGIDO" if invalidos else "OK",
        "detalhe": f"Removidos: {', '.join(invalidos)}" if invalidos else "Códigos conferidos com a base.",
    })

    soma = somar_minutos(plano_final)
    verificacoes_codigo.append({
        "pergunta": f"A soma dos tempos das etapas é {duracao} minutos?",
        "resultado": "OK" if soma == duracao else "ATENÇÃO",
        "detalhe": f"Soma das etapas: {soma} min." + ("" if soma == duracao else " Ajuste os tempos antes de usar."),
    })

    resultado = {
        "pedido": log["pedido"],
        "analise": analise,
        "candidatas": [h["codigo"] for h in candidatas],
        "selecao": selecao,
        "habilidades": habilidades_finais,
        "plano": plano_final,
        "verificacoes_modelo": verificacao.get("verificacoes", []),
        "verificacoes_codigo": verificacoes_codigo,
    }
    log["resultado"] = {"habilidades": [h["codigo"] for h in habilidades_finais],
                        "verificacoes_codigo": verificacoes_codigo}
    resultado["arquivo_log"] = str(salvar_log(log))
    return resultado


def salvar_log(log: dict) -> Path:
    PASTA_LOGS.mkdir(exist_ok=True)
    nome = f"{datetime.now():%Y%m%d-%H%M%S}-{log['pedido']['serie']}ano.json"
    caminho = PASTA_LOGS / nome
    caminho.write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
    return caminho


def plano_em_markdown(resultado: dict) -> str:
    """Monta o plano final em markdown, com o texto oficial de cada habilidade vindo da base."""
    p, pedido = resultado["plano"], resultado["pedido"]
    linhas = [f"# {p.get('titulo', 'Plano de aula')}", "",
              f"**Série:** {pedido['serie']}º ano · **Componente:** Matemática · "
              f"**Duração:** {pedido['duracao']} minutos · **Tema:** {pedido['tema']}", "",
              "## 1. Habilidades da BNCC", ""]
    for h in resultado["habilidades"]:
        marca = " (retomada)" if h["tipo"] == "retomada" else ""
        linhas.append(f"- **{h['codigo']}**{marca}: {h['texto']}")
    linhas += ["", "## 2. Objetivos de aprendizagem", ""] + [f"- {o}" for o in p.get("objetivos", [])]
    linhas += ["", "## 3. Etapas da aula", "", "| Tempo | Etapa | Professor | Alunos |", "| --- | --- | --- | --- |"]
    for e in p.get("etapas", []):
        linhas.append(f"| {e.get('minutos', '')} min | {e.get('nome', '')} | {e.get('professor', '')} | {e.get('alunos', '')} |")
    linhas += ["", "## 4. Recursos didáticos", ""] + [f"- {r}" for r in p.get("recursos", [])]
    linhas += ["", "## 5. Avaliação", "", p.get("avaliacao", ""), "", "## 6. Exercícios e gabarito", ""]
    for i, ex in enumerate(p.get("exercicios", []), 1):
        linhas.append(f"{i}. {ex.get('enunciado', '')}  \n   **Resposta:** {ex.get('resposta', '')}")
    linhas += ["", "---", "", "Gerado pelo AulaCerta. Revise o plano antes de usar em sala.",
               "Referência: BRASIL. Ministério da Educação. Base Nacional Comum Curricular. Brasília: MEC, 2018."]
    return "\n".join(linhas)
