"""Os 4 prompts da cadeia. Todos respondem em JSON para o código poder ler a saída."""

# Prompt 1 – Análise do pedido (Step-Back + Least-to-Most)
PROMPT_1_ANALISE = """Você é um especialista em currículo de Matemática da educação básica brasileira.

Um professor quer planejar uma aula com estes dados:
- Série: {serie}º ano do ensino fundamental
- Componente: Matemática
- Tema: {tema}
- Duração: {duracao} minutos
- Perfil da turma: {perfil}

Antes de pensar na aula, dê um passo atrás e responda: que conceitos maiores esse tema mobiliza e que conhecimentos o aluno precisa ter antes?

Depois, divida o tema em subtópicos do mais simples ao mais complexo, de forma que cada um prepare o seguinte e que caibam em {duracao} minutos.

Por fim, liste de 4 a 8 palavras-chave que apareceriam no texto oficial da BNCC sobre esse tema (por exemplo: "equações", "incógnita", "igualdade").

Responda APENAS com um JSON válido, neste formato:
{{
  "conceitos": ["..."],
  "pre_requisitos": ["..."],
  "subtopicos": ["..."],
  "palavras_chave": ["..."]
}}"""

# Prompt 2 – Seleção de habilidades (Few-shot + Chain-of-Thought)
PROMPT_2_SELECAO = """Você seleciona habilidades da BNCC para um plano de aula.

Tema: {tema} | Série: {serie}º ano
Subtópicos: {subtopicos}

Habilidades candidatas (use SOMENTE estas; nunca crie um código):
{candidatas}

Regras:
1. Escolha de 1 a 3 habilidades que correspondam diretamente ao tema.
2. Se a habilidade for de uma série anterior ao {serie}º ano, marque o tipo como "retomada"; se for do {serie}º ano, marque como "principal".
3. Descarte habilidades cujo texto trate de outro conteúdo, mesmo que sejam da mesma série.
4. Selecione apenas habilidades cuja ação e objeto de conhecimento serão efetivamente trabalhados nas etapas da aula, não apenas citados nos objetivos.
5. Não inclua habilidades genéricas (por exemplo, operações aritméticas ou estimativa) apenas porque são pré-requisitos indiretos do tema.
6. Quando a habilidade exigir demonstração, elaboração de problemas ou outro processo específico, somente selecione se esse processo couber no tempo e puder ser explicitamente contemplado no plano.
7. Se nenhuma candidata tiver aderência direta, devolva "selecionadas": [] e explique a limitação; não force correspondências.

Exemplo:
Tema: equações do 1º grau | Série: 8º ano
Candidatas: EF07MA18 (7º ano, equações redutíveis a ax + b = c), EF08MA07 (8º ano, equação com duas incógnitas e reta no plano cartesiano)
Resposta:
{{
  "raciocinio": "O tema é equação com uma incógnita. EF07MA18 trata exatamente disso, mas é do 7º ano, então entra como retomada. EF08MA07 trata de duas incógnitas e plano cartesiano, que é outro conteúdo, então é descartada.",
  "selecionadas": [{{"codigo": "EF07MA18", "tipo": "retomada", "justificativa": "Trata de equações do 1º grau com uma incógnita."}}],
  "descartadas": [{{"codigo": "EF08MA07", "motivo": "Trata de equação com duas incógnitas e reta no plano cartesiano."}}]
}}

Agora faça o mesmo para o tema acima. No campo "raciocinio", forneça uma justificativa breve, objetiva e verificável para as escolhas e exclusões.
Responda APENAS com um JSON válido no mesmo formato do exemplo."""

# Prompt 3 – Redação do plano (Role Prompt + modelo fixo de saída)
PROMPT_3_PLANO = """Você é um coordenador pedagógico experiente, que revisa planos de aula de Matemática há 15 anos.

Escreva um plano de aula para:
- Série: {serie}º ano | Duração: {duracao} minutos | Tema: {tema}
- Perfil da turma: {perfil}
- Subtópicos em ordem: {subtopicos}
- Habilidades BNCC (já verificadas; use só estas): {habilidades}

Regras:
- De 2 a 4 objetivos, cada um começando com um verbo.
- A soma dos minutos das etapas deve ser EXATAMENTE {duracao}.
- Recursos: só o que uma escola pública comum tem.
- Pelo menos 4 exercícios com a resposta correta. Confira cada conta.
- Cada enunciado deve ser autossuficiente: inclua todos os dados necessários, relações geométricas, unidades e a grandeza solicitada. Não presuma posições ou ângulos que não foram informados.
- Inclua exercícios progressivos e ao menos um problema contextualizado matematicamente inequívoco.
- Para problemas geométricos, declare explicitamente quando há ângulo reto e quais segmentos são catetos ou hipotenusa, ou forneça descrição suficiente para identificá-los.
- As etapas devem trabalhar de forma observável as ações exigidas pelas habilidades selecionadas (por exemplo, demonstrar, resolver ou elaborar), e não apenas mencioná-las nos objetivos.
- Se uma habilidade exigir demonstração, descreva o método empregado; não use apenas a expressão genérica "demonstrar o teorema".
- A avaliação deve explicitar evidências de aprendizagem e critérios observáveis, adequados ao perfil da turma.
- Não cite nenhuma habilidade fora da lista recebida.

Responda APENAS com um JSON válido, neste formato:
{{
  "titulo": "...",
  "habilidades": [{{"codigo": "...", "tipo": "principal ou retomada"}}],
  "objetivos": ["..."],
  "etapas": [{{"minutos": 10, "nome": "...", "professor": "o que o professor faz", "alunos": "o que os alunos fazem"}}],
  "recursos": ["..."],
  "avaliacao": "como avaliar e com quais critérios",
  "exercicios": [{{"enunciado": "...", "resposta": "..."}}]
}}"""

# Prompt 4 – Verificação (Chain-of-Verification)
PROMPT_4_VERIFICACAO = """Você é um revisor rigoroso. Sua tarefa é verificar o plano de aula abaixo antes que ele chegue ao professor.

Plano (JSON):
{plano}

Habilidades oficiais da BNCC (fonte de verdade):
{habilidades}

Duração pedida: {duracao} minutos.

Passo 1. Escreva as perguntas de verificação. Inclua pelo menos:
- Todo código citado no plano está na fonte de verdade?
- Os objetivos e as etapas trabalham de fato essas habilidades?
- A soma dos minutos das etapas é {duracao}?
- Cada resposta dos exercícios está correta? Refaça as contas independentemente.
- Cada enunciado fornece dados suficientes e sem ambiguidade para determinar a resposta? Há relações geométricas implícitas não justificadas?
- As etapas contemplam explicitamente as ações exigidas pelas habilidades selecionadas, sem apenas citá-las nos objetivos?
- Há adequação ao perfil da turma e critérios de avaliação observáveis?

Passo 2. Responda cada pergunta de forma independente, sem confiar no que o plano afirma.

Passo 3. Corrija somente os problemas efetivamente identificados e devolva o plano completo, no mesmo formato JSON recebido.

Regras obrigatórias para os resultados:
- Use "OK" quando a verificação estiver satisfatória e nenhuma alteração correspondente tiver sido necessária.
- Use "CORRIGIDO" somente se o plano devolvido realmente contiver uma mudança verificável relacionada à pergunta. Explique no detalhe o trecho anterior e o novo trecho, ou descreva precisamente a alteração.
- Use "ATENÇÃO" se identificar uma limitação que não conseguiu resolver. Nunca afirme que corrigiu algo que permaneceu igual.
- Para a duração, some explicitamente os minutos; se a soma já estiver correta, marque "OK" e não invente ajuste.
- Confira TODOS os exercícios. Se um enunciado for ambíguo, reescreva-o com os dados necessários e mantenha o gabarito coerente.
- Não invente novos códigos BNCC. Preserve os campos e a estrutura JSON do plano.
- No detalhe, descreva somente verificações realmente efetuadas e mudanças efetivas.

Responda APENAS com um JSON válido, neste formato:
{{
  "verificacoes": [{{"pergunta": "...", "resultado": "OK, CORRIGIDO ou ATENÇÃO", "detalhe": "o que foi conferido ou o que mudou"}}],
  "plano": {{ ...o plano completo, no mesmo formato recebido... }}
}}"""
