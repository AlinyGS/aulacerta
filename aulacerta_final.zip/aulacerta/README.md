# AulaCerta 📐

Gerador de planos de aula de Matemática (6º ao 9º ano) com habilidades da BNCC **conferidas numa base oficial**.

Trabalho da disciplina Fundamentos de Inteligência Artificial, professor Marcos Assunção.
Equipe: Aliny, Bernardo, Henrique e Ranya.

## O problema

Professores gastam horas montando planos de aula alinhados à BNCC. Ferramentas de IA já ajudam, mas no nosso benchmark elas citaram habilidades que existem e não combinam com o tema. Com o pedido "equações do 1º grau, 8º ano", o Gemini usou a EF08MA07 (equação com duas incógnitas) e o ChatGPT a EF08MA06 (valor numérico de expressões), e o Teachy não citou código nenhum. O AulaCerta resolve isso: a IA só pode escolher habilidades que o código encontrou na base, e o plano passa por verificações antes de chegar ao professor.

## Como funciona

```
Formulário do professor
   ↓
Prompt 1 · Análise do pedido (Step-Back + Least-to-Most) → subtópicos e palavras-chave
   ↓
Busca na base BNCC (código, sem IA) → habilidades candidatas
   ↓
Prompt 2 · Seleção de habilidades (Few-shot + Chain-of-Thought) → principal ou retomada
   ↓
Prompt 3 · Redação do plano (Role Prompt + modelo fixo em JSON)
   ↓
Prompt 4 · Verificação (Chain-of-Verification)
   ↓
Conferência em Python (+ correção de duração, se preciso)
   ↓
Plano final + relatório de verificação → o professor revisa
```

O que é exato fica com o código, não com a IA:

- códigos BNCC fora da base são descartados;
- o tipo "retomada" é decidido pela série da habilidade;
- o texto oficial de cada habilidade vem do CSV;
- a soma dos tempos das etapas é conferida. Se não bater, o código pede um ajuste à IA e só aceita a resposta se a soma fechar e o resto do plano continuar igual;
- quando o prompt 4 diz que corrigiu algo, o código compara o plano antes e depois. Se nada mudou, o resultado vira ATENÇÃO.

## Como rodar

1. Instale o Python 3.10 ou mais novo.
2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Copie `.env.example` para `.env` e coloque a chave da API da OpenAI:
   ```
   OPENAI_API_KEY=sk-...
   OPENAI_MODEL=gpt-4o-mini
   ```
   O `.env` nunca deve ir para o GitHub (já está no `.gitignore`). A API da OpenAI é cobrada à parte da assinatura do ChatGPT. Com o gpt-4o-mini, cada plano custa menos de um centavo de dólar.
4. Abra a aplicação:
   ```bash
   streamlit run app.py
   ```
5. Para rodar os 3 casos de teste e gerar os logs:
   ```bash
   python testar_casos.py
   ```

## Arquivos

| Arquivo | O que faz |
| --- | --- |
| `app.py` | Tela em Streamlit: formulário, plano, verificação e a cadeia de prompts passo a passo |
| `cadeia.py` | Executa a cadeia, valida cada saída, confere códigos e tempos, corrige a duração e grava o log |
| `prompts.py` | Os 4 prompts |
| `bncc.py` | Carrega a base e faz a busca por palavras-chave |
| `bncc_matematica.csv` | As 121 habilidades de Matemática do 6º ao 9º ano |
| `testar_casos.py` | Roda os 3 casos de teste |
| `logs/` | Um JSON por execução, com a saída de cada prompt e as verificações |
| `versoes_anteriores/` | Versões anteriores de `cadeia.py` e `prompts.py`, mantidas para mostrar a evolução do sistema |

## Testes

A pasta `logs/` tem as 10 execuções de 7 de novembro de 2026: 7 do desenvolvimento, feitas pela tela, e 3 finais, feitas pelo `testar_casos.py`.

| Caso final | Série e tema | Duração | Habilidades escolhidas | Log |
| --- | --- | --- | --- | --- |
| 1 | 8º ano, equações do 1º grau | 50 min | EF07MA18 (retomada) | `20261107-144847-8ano.json` |
| 2 | 6º ano, adição e subtração de frações | 50 min | EF06MA10 e EF06MA07 | `20261107-144920-6ano.json` |
| 3 | 9º ano, teorema de Pitágoras | 100 min | EF09MA13 e EF09MA14 | `20261107-144954-9ano.json` |

Nos 3 casos, as habilidades foram pertinentes, nenhum código foi inventado, as 12 contas dos exercícios estão certas e a duração bateu. Um teste de desenvolvimento mostrou por que a conferência em código existe: o prompt 4 afirmou que uma aula somava 100 minutos quando somava 110, e só o Python percebeu (`20261107-143515-9ano.json`). A análise completa está no relatório técnico do grupo.

## Limitações

- Só Matemática do 6º ao 9º ano.
- A busca é por palavras-chave. Se o tema for descrito de um jeito muito diferente da BNCC, ela pode não achar a habilidade, e nesse caso o sistema avisa em vez de inventar.
- O prompt 4 também é um modelo de linguagem e pode errar. Nos testes, ele aprovou um exercício que pergunta "quantos pedaços restam" com resposta 5/8 e outro que pede a "diagonal" de um triângulo. Por isso o relatório de verificação fica visível e o professor revisa o plano antes de usar.

## Fonte dos dados

Habilidades da [Base Nacional Comum Curricular](https://basenacionalcomum.mec.gov.br/) (BRASIL, MEC, 2018), Matemática, anos finais do ensino fundamental.
