"""Base BNCC: carrega o CSV e busca habilidades candidatas (sem IA)."""
import csv
import unicodedata
from pathlib import Path

ARQUIVO = Path(__file__).parent / "bncc_matematica.csv"

# Palavras muito comuns que não ajudam a achar a habilidade certa
PARADAS = {
    "para", "como", "com", "sem", "uma", "uns", "das", "dos", "nas", "nos", "pela", "pelo",
    "entre", "sobre", "que", "seus", "suas", "este", "esta", "isso", "aula", "alunos",
    "aluno", "turma", "conceito", "conceitos", "problemas", "resolver", "resolucao",
    "elaborar", "numeros", "numero", "matematica",
}


def normalizar(texto: str) -> str:
    """Minúsculas e sem acentos: 'Equações' -> 'equacoes'."""
    texto = unicodedata.normalize("NFKD", texto.lower())
    return "".join(c for c in texto if not unicodedata.combining(c))


def radical(palavra: str) -> str:
    """Corta a palavra em 5 letras para casar singular e plural (equacao/equacoes)."""
    return palavra[:5]


def carregar_base() -> dict:
    """Devolve um dicionário {codigo: habilidade}."""
    with open(ARQUIVO, encoding="utf-8") as f:
        return {linha["codigo"]: {**linha, "ano": int(linha["ano"])} for linha in csv.DictReader(f)}


def buscar(base: dict, serie: int, palavras_chave: list[str], limite: int = 12) -> list[dict]:
    """Habilidades da série pedida e das anteriores, ordenadas pelas palavras-chave que contêm."""
    radicais = set()
    for termo in palavras_chave:
        for palavra in normalizar(termo).replace("-", " ").split():
            palavra = palavra.strip(".,;:()º°")
            if len(palavra) >= 4 and palavra not in PARADAS:
                radicais.add(radical(palavra))

    resultado = []
    for hab in base.values():
        if hab["ano"] > serie:
            continue
        texto = normalizar(hab["texto"] + " " + hab["objeto_conhecimento"])
        radicais_do_texto = {radical(p.strip(".,;:()“”")) for p in texto.split()}
        pontos = len(radicais & radicais_do_texto)
        if pontos:
            # Desempate: a série pedida vem antes das anteriores
            resultado.append((pontos, hab["ano"] == serie, hab))

    resultado.sort(key=lambda r: (r[0], r[1]), reverse=True)
    return [hab for _, _, hab in resultado[:limite]]
